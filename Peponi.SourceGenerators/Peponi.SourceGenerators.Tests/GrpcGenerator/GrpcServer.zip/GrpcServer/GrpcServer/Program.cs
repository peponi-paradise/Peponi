﻿using Grpc.Core;
using HelloWorld;

namespace GrpcServer
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            var server = new Server()
            {
                Ports = { new ServerPort("localhost", 9091, ServerCredentials.Insecure) }
            };
            GetServices().ForEach(server.Services.Add);

            server.Start();

            var type = typeof(HelloWorldCommunicationService);

            Console.WriteLine("Now started server. Listening on the port : 9091");
            Console.ReadLine();
        }

        private static List<ServerServiceDefinition> GetServices()
        {
            List<ServerServiceDefinition> rtns = new();
            rtns.Add(HelloWorldCommunication.BindService(new HelloWorldCommunicationService()));
            return rtns;
        }
    }

    internal class HelloWorldCommunicationService : HelloWorldCommunication.HelloWorldCommunicationBase
    {
        public override Task<CommunicationMessage> HelloRequest(CommunicationMessage request, ServerCallContext context)
        {
            return Task.FromResult(new CommunicationMessage
            {
                Sender = "Server : 9091",
                Message = "Hello world from server"
            });
        }
    }
}