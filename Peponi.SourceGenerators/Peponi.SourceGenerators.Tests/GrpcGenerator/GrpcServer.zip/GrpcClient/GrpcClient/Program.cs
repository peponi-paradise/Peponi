﻿using Grpc.Core;

namespace GrpcClient
{
    internal class Program
    {
        private static async Task Main(string[] args)
        {
            var channel = new Channel("localhost", 9091, ChannelCredentials.Insecure);

            var client = new HelloWorld.HelloWorldCommunication.HelloWorldCommunicationClient(channel);
            var reply = await client.HelloRequestAsync(new HelloWorld.CommunicationMessage
            {
                Sender = "Client",
                Message = "Hello world from client"
            });
            Console.WriteLine(reply);
            Console.ReadLine();
        }
    }
}