﻿using HelloWorld;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace ClientFactory
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            var host = CreateHostBuilder(args);
            host.Build().Run();
        }

        // Additional configuration is required to successfully run gRPC on macOS.
        // For instructions on how to configure Kestrel and gRPC clients on macOS, visit https://go.microsoft.com/fwlink/?linkid=2099682
        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }

    public class Startup
    {
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddGrpc();
            services.AddGrpcClient<HelloWorld.HelloWorldCommunication.HelloWorldCommunicationClient>(o => o.Address = new Uri("http://localhost:9091"));
            services.AddTransient<Service>();

            var rtn = services.BuildServiceProvider();

            rtn.GetRequiredService<Service>().Hello();
        }
    }

    public class Service
    {
        private HelloWorldCommunication.HelloWorldCommunicationClient HelloWorldCommunicationClient { get; set; }

        public Service(HelloWorldCommunication.HelloWorldCommunicationClient client)
        {
            HelloWorldCommunicationClient = client;
        }

        public void Hello()
        {
            var rtn = HelloWorldCommunicationClient.HelloRequest(new() { Sender = "Client", Message = "Hello" });
            Console.WriteLine(rtn);
        }
    }
}